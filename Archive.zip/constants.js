export const PUBLIC_URL="http://lamisplus.org/demo/"
