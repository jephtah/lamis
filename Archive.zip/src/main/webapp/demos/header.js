import user1Image from '../assets/img/users/100_4.png';



export const notificationsData = [
  {
    id: 1,
    avatar: user1Image,
    message: 'David sent you a message',
    date: '3 min ago',
  },
  {
    id: 2,
    avatar: user1Image,
    message: 'Jane mentioned you here',
    date: '1 hour ago',
  },
  
];
