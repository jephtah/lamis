export const url = 'http://lamisplus.org/base-module/api/';
export const HIVSERVICECODE = "";
export const LABSERVICECODE = "87cb9bc7-ea0d-4c83-a70d-b57a5fb7769e";
export const PHARMACYSERVICECODE = "";
