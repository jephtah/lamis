 import { Content } from '../Layout';
import React from 'react';

const EmptyLayout = ({ children, ...restProps }) => (
  <main className="cr-app bg-light" {...restProps}>
    <Content fluid style={{backgroundColor:'#000'}}>
        {children}
    </Content> 

  </main>
);

export default EmptyLayout;
