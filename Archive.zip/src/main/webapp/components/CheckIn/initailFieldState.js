export const initialfieldState_checkInPatient = {
        dateVisitStart: new Date(), 
        timeVisitStart: '', 
        visitTypeId:'', 
        patientId:'' 
}